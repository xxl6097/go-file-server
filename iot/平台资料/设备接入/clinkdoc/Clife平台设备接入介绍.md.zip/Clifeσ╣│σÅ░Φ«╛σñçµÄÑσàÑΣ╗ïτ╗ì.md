# Clife平台设备接入介绍

## Clife平台接入方式

### 非标准接入方式

非标准接入方式，主要是接入第三方厂商设备，转换第三方协议为clife平台协议，这种方式的接入通讯方式主要分以下几种：

#### 1. MQTT通讯方式

通过开发Clink端后台程序，订阅第三方的的MQTT服务，转换第三方协议，实现设备接入clife平台。

#### 2. HTTP通讯方式

这种方式一般有第三方提供Api接口，开发Clink端程序，通过接口过去第三方设备协议数据后转换，实现设备接入clife平台。


#### 3. NSQ通讯方式

与MQTT方式类似。


### 标准接入方式

标准接入方式，是指接入的设备使用clife平台协议。其通讯方式主要分以下几种：

#### 1. TCP接入方式

##### 内置Android系统

 内置Andorid操作系统，集成Clife提供连接平台的IoT Open SDK，打通了设备数据上下行，在Clife平台上新建产品与物模型，即可以实现设备快速接入Clife平台

##### Wi-Fi模组

 由数联天下提供Wi-Fi模组与对应SDK，设备MCU集成对应的Wi-Fi模组SDK，即可以实现设备接入clife平台。

##### Linux系统

 由数联天下提供不同cpu架构的Linux系统对应SDK，设备端集成，即可以实现设备接入clife平台



#### 2. HTTP接入方式

##### 带操作系统

带有操作系统的硬件设备，其中系统包括windows、Linux。使用http方式，实现Clife端接口，即可以快速接入clife平台。

##### Wi-Fi模组

由数联天下提供Wi-Fi模组与对应SDK，设备MCU集成对应的Wi-Fi模组SDK，即可以实现设备接入clife平台。

#### 3. 蓝牙方式

##### 空调盒子

蓝牙设备遵循clife蓝牙协议，通过clife开发的蓝牙盒子，可实现设备开始接入clife平台。

##### App上报

通过手机与蓝牙设备连接，手机App将设备蓝牙数据上报到clife平台。

#### 4. 以太网方式

##### Zigbee

硬件端实现clife协议，通过tcp方式连接clife平台，实现快速接入clife平台。

##### NB-IOT

硬件端实现clife协议，通过tcp方式连接clife平台，实现快速接入clife平台。

##### 3G/4G

硬件端实现clife协议，通过tcp方式连接clife平台，实现快速接入clife平台。


#### 5. 网关方式

通过clife开发的IoT路由器接入clife平台，设备端遵循clife IoT路由器协议，数据通过IoT路由器转发指clife平台。

#### 目前还可支持红外、MESH、Lora等等


