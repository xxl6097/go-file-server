package com.example.bluetoothlibrary.entity;

/**
 * Created by laiyiwen on 2017/4/7.
 */
public class BleData {
    private int byte1;
    private int byte2;
    private int byte3;
    private int byte4;
    public int getByte1() {
        return byte1;
    }
    public void setByte1(int byte1) {
        this.byte1 = byte1;
    }
    public int getByte2() {
        return byte2;
    }
    public void setByte2(int byte2) {
        this.byte2 = byte2;
    }
    public int getByte3() {
        return byte3;
    }
    public void setByte3(int byte3) {
        this.byte3 = byte3;
    }
    public int getByte4() {
        return byte4;
    }
    public void setByte4(int byte4) {
        this.byte4 = byte4;
    }
}
