package com.example.bluetoothlibrary.entity;

/**
 * Created by laiyiwen on 2017/4/7.
 */
public class Constant {
    public final static String BLT_WBP = "BLT_WBP";
    public final static String AL_WBP = "AL_WBP";
    public final static String BLT_M70C = "BLT_M70C";
    public final static String BLT_MODT = "BLT_MODT";
    public final static String AL_WT1 = "AL_WT1";
    public final static String BLT_WT2 = "BLT_WT2";
    public final static String AL_WT2 = "AL_WT2";
    public final static String WT2 = "WT2";
    public final static String WT1 = "WT1";
    public final static String M70C = "M70C";
    public final static String WT3 = "WT3";
    public final static String WBP100 = "WBP100";
    public final static String WBP101 = "WBP101";
    public final static String WBP202 = "WBP202";
    public final static String WBP204 = "WBP204";
    public final static String BLT_WF1= "BLT_WF1";
}
